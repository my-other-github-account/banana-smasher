from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from banana_smasher.backpack_dimensions import (
    bind_mixed_v7_physical_dimensions,
    DynamicDimensionsError,
    preflight_mixed_backpack_config,
    preflight_mixed_v7_recovery_plan,
    solve_mixed_backpack_config,
)
from banana_smasher import solve_mixed_backpack_config as public_solve_mixed_backpack_config
from banana_smasher import (
    preflight_mixed_backpack_config as public_preflight_mixed_backpack_config,
)
from banana_smasher.cli import main


BASIS = "a" * 64
CLASSES = ("agentic", "chat", "code", "multilingual", "prose", "reasoning")


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + "\n")


def _dimension_rows(path: Path) -> None:
    rows = []
    for layer, tiers in ((0, ("qtip2", "qtip3")), (1, ("qtip2",))):
        for tier in tiers:
            rows.append(
                {
                    "schema": "banana-smasher-dynamic-backpack-candidate-ledger-row-v2",
                    "status": "ADMITTED_COMPLETE_ALLOCATION_ELIGIBLE",
                    "allocation_eligible": True,
                    "basis_sha256": BASIS,
                    "candidate_id": f"L{layer:03d}.E000.down.{tier}",
                    "layer": layer,
                    "expert": 0,
                    "projection": "down",
                    "tier": tier,
                    "physical_bytes": 1 if tier == "qtip2" else 2,
                    "six_class_predictions": {
                        name: 1.0 if tier == "qtip2" else 0.1 for name in CLASSES
                    },
                    "activation_artifacts": [],
                }
            )
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows))


def test_preflight_mixed_v7_recovery_closes_source_and_sensitivity_contract(
    tmp_path: Path,
) -> None:
    terminal = tmp_path / "L002_SOURCE_TERMINAL.json"
    _write_json(
        terminal,
        {
            "status": "PASS",
            "basis_index_sha256": BASIS,
            "layer": 2,
            "path": "/source/model-00004-of-00048.safetensors",
            "bytes": 123,
            "sha256": "b" * 64,
        },
    )
    terminal_raw = terminal.read_bytes()
    plan = tmp_path / "recovery.json"
    _write_json(
        plan,
        {
            "schema": "banana-smasher-mixed-v7-recovery-plan-v1",
            "basis_sha256": BASIS,
            "canonical_commit_sha": "c" * 40,
            "selection_policy": {
                "selected_layers": [2],
                "experts_per_layer": 1,
                "additional_qtip3_expert_options": 1,
                "minimum_required_options": 1,
            },
            "layers": [
                {
                    "layer": 2,
                    "source_stage_terminal": {
                        "path": str(terminal),
                        "bytes": len(terminal_raw),
                        "sha256": hashlib.sha256(terminal_raw).hexdigest(),
                    },
                    "source_payload": {
                        "path": "/source/model-00004-of-00048.safetensors",
                        "bytes": 123,
                        "sha256": "b" * 64,
                    },
                    "capture": {"path": "/capture/L002.pt", "sha256": "d" * 64},
                }
            ],
        },
    )
    plan_raw = plan.read_bytes()
    contract = tmp_path / "sensitivity.json"
    _write_json(
        contract,
        {
            "schema": "banana-smasher-mixed-v7-sensitivity-extraction-contract-v1",
            "basis_sha256": BASIS,
            "canonical_commit_sha": "c" * 40,
            "recovery_plan": {
                "path": str(plan),
                "bytes": len(plan_raw),
                "sha256": hashlib.sha256(plan_raw).hexdigest(),
            },
            "inputs": {"layers": [{"layer": 2}]},
            "output": {"expected_rows": 1},
        },
    )

    receipt = preflight_mixed_v7_recovery_plan(plan, contract)

    assert receipt["status"] == "PASS_READY_TO_CAS"
    assert receipt["selected_layers"] == [2]
    assert receipt["source_payload_bytes"] == 123

    payload = json.loads(terminal.read_text())
    payload["basis_index_sha256"] = "e" * 64
    _write_json(terminal, payload)
    with pytest.raises(DynamicDimensionsError, match="descriptor mismatch"):
        preflight_mixed_v7_recovery_plan(plan, contract)


def _config(tmp_path: Path, *, target: int) -> Path:
    dimensions = tmp_path / "dimensions.jsonl"
    _dimension_rows(dimensions)
    config = tmp_path / f"mixed-{target}.json"
    _write_json(
        config,
        {
            "schema": "banana-smasher-mixed-backpack-config-v1",
            "basis_sha256": BASIS,
            "target": {
                "whole_model_bytes": target,
                "fixed_nonexpert_bytes": 10,
                "exact": True,
            },
            "allowed_tiers": ["qtip2", "qtip3"],
            "fallback_tier": "qtip2",
            "dimensions": {
                "path": str(dimensions),
                "sha256": hashlib.sha256(dimensions.read_bytes()).hexdigest(),
            },
            "class_caps": {name: 10.0 for name in CLASSES},
        },
    )
    return config


def test_mixed_config_forces_q2_where_q3_inventory_is_missing(tmp_path: Path) -> None:
    assert public_solve_mixed_backpack_config is solve_mixed_backpack_config
    config = _config(tmp_path, target=13)
    output = tmp_path / "solve"

    receipt = solve_mixed_backpack_config(config, output=output)

    assert receipt["byte_accounting"] == {
        "fixed_nonexpert_bytes": 10,
        "candidate_payload_bytes": 3,
        "whole_model_bytes": 13,
        "target_whole_model_bytes": 13,
        "slack_bytes": 0,
    }
    identity = json.loads((output / "identity.json").read_text())
    assert identity["assignment"] == {
        "L000.E000": "qtip3",
        "L001.E000": "qtip2",
    }
    assert identity["coverage"]["qtip3"] == {
        "available_cells": 1,
        "missing_layers": [1],
    }
    assert identity["composition"]["layers"] == [
        {"layer": 0, "tiers": {"qtip3": 1}},
        {"layer": 1, "tiers": {"qtip2": 1}},
    ]


def test_mixed_config_defaults_to_native_q3_q2_tiers(tmp_path: Path) -> None:
    config = _config(tmp_path, target=13)
    value = json.loads(config.read_text())
    del value["allowed_tiers"]
    _write_json(config, value)
    schema = json.loads(
        (
            Path(__file__).resolve().parents[1]
            / "schema/banana-smasher-mixed-backpack-config-v1.schema.json"
        ).read_text()
    )
    pytest.importorskip("jsonschema").validate(value, schema)

    receipt = solve_mixed_backpack_config(config, output=tmp_path / "solve")

    assert receipt["allowed_tiers"] == ["native_mxfp4", "qtip3", "qtip2"]
    identity = json.loads((tmp_path / "solve/identity.json").read_text())
    assert identity["allowed_tiers"] == ["native_mxfp4", "qtip3", "qtip2"]


def test_mixed_config_selects_one_tier_per_expert_across_both_projections(
    tmp_path: Path,
) -> None:
    dimensions = tmp_path / "dimensions.jsonl"
    rows = []
    for layer, tiers in ((0, ("qtip2", "qtip3")), (1, ("qtip2",))):
        for projection in ("down", "fused13"):
            for tier in tiers:
                rows.append(
                    {
                        "schema": "banana-smasher-dynamic-backpack-candidate-ledger-row-v2",
                        "status": "ADMITTED_COMPLETE_ALLOCATION_ELIGIBLE",
                        "allocation_eligible": True,
                        "basis_sha256": BASIS,
                        "candidate_id": f"L{layer:03d}.E000.{projection}.{tier}",
                        "layer": layer,
                        "expert": 0,
                        "projection": projection,
                        "tier": tier,
                        "physical_bytes": 1 if tier == "qtip2" else 2,
                        "six_class_predictions": {
                            name: 1.0 if tier == "qtip2" else 0.1 for name in CLASSES
                        },
                        "activation_artifacts": [],
                    }
                )
    dimensions.write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    )
    config = tmp_path / "mixed.json"
    _write_json(
        config,
        {
            "schema": "banana-smasher-mixed-backpack-config-v1",
            "basis_sha256": BASIS,
            "target": {
                "whole_model_bytes": 16,
                "fixed_nonexpert_bytes": 10,
                "exact": True,
            },
            "allowed_tiers": ["qtip2", "qtip3"],
            "fallback_tier": "qtip2",
            "dimensions": {
                "path": str(dimensions),
                "sha256": hashlib.sha256(dimensions.read_bytes()).hexdigest(),
            },
            "class_caps": {name: 10.0 for name in CLASSES},
        },
    )

    solve_mixed_backpack_config(config, output=tmp_path / "solve")

    identity = json.loads((tmp_path / "solve/identity.json").read_text())
    assert identity["assignment"] == {
        "L000.E000": "qtip3",
        "L001.E000": "qtip2",
    }
    assignment = json.loads((tmp_path / "solve/ASSIGNMENT.json").read_text())
    assert assignment["materialization_assignments"] == [
        {"cell_id": "L000.E000.down", "tier": "qtip3"},
        {"cell_id": "L000.E000.fused13", "tier": "qtip3"},
        {"cell_id": "L001.E000.down", "tier": "qtip2"},
        {"cell_id": "L001.E000.fused13", "tier": "qtip2"},
    ]


def test_budget_is_a_config_only_change_and_cli_uses_same_api(
    tmp_path: Path, capsys
) -> None:
    config = _config(tmp_path, target=12)
    output = tmp_path / "solve"

    assert (
        main(
            [
                "backpack",
                "solve-mixed",
                "--config",
                str(config),
                "--output",
                str(output),
            ]
        )
        == 0
    )
    emitted = json.loads(capsys.readouterr().out)
    assert emitted["command"] == "backpack solve-mixed"
    assert emitted["byte_accounting"]["whole_model_bytes"] == 12
    assert json.loads((output / "identity.json").read_text())["assignment"] == {
        "L000.E000": "qtip2",
        "L001.E000": "qtip2",
    }


def test_mixed_config_has_a_public_json_schema(tmp_path: Path) -> None:
    jsonschema = pytest.importorskip("jsonschema")
    schema = json.loads(
        (
            Path(__file__).resolve().parents[1]
            / "schema/banana-smasher-mixed-backpack-config-v1.schema.json"
        ).read_text()
    )

    jsonschema.validate(json.loads(_config(tmp_path, target=13).read_text()), schema)


def test_preflight_accepts_partial_dimensions_and_reports_pending_locator(
    tmp_path: Path, capsys,
) -> None:
    dimensions = tmp_path / "partial.jsonl"
    _dimension_rows(dimensions)
    config = tmp_path / "mixed.json"
    _write_json(
        config,
        {
            "schema": "banana-smasher-mixed-backpack-config-v1",
            "basis_sha256": BASIS,
            "target": {
                "whole_model_bytes": 13,
                "fixed_nonexpert_bytes": 10,
                "exact": True,
            },
            "allowed_tiers": ["qtip2", "qtip3"],
            "fallback_tier": "qtip2",
            "topology": {
                "layers": [0, 1, 2],
                "experts_per_layer": 1,
                "projections": ["down"],
            },
            "dimensions": {
                "sources": [
                    {
                        "path": str(dimensions),
                        "sha256": hashlib.sha256(dimensions.read_bytes()).hexdigest(),
                    },
                    {"locator_path": "final-dimensions-locator.json"},
                ]
            },
            "class_caps": {name: 10.0 for name in CLASSES},
        },
    )

    schema = json.loads(
        (
            Path(__file__).resolve().parents[1]
            / "schema/banana-smasher-mixed-backpack-config-v1.schema.json"
        ).read_text()
    )
    pytest.importorskip("jsonschema").validate(json.loads(config.read_text()), schema)

    receipt = preflight_mixed_backpack_config(config)

    assert public_preflight_mixed_backpack_config is preflight_mixed_backpack_config
    assert receipt["status"] == "WAITING_FOR_DIMENSION_LOCATORS"
    assert receipt["ready_to_solve"] is False
    assert receipt["sources"] == {"admitted": 1, "pending": 1}
    assert receipt["coverage"]["qtip2"]["available_projection_cells"] == 2
    assert receipt["coverage"]["qtip2"]["missing_layers"] == [2]
    assert receipt["missing_fallback_projection_cells"] == ["L002.E000.down"]
    assert main(["backpack", "preflight-mixed", "--config", str(config)]) == 0
    emitted = json.loads(capsys.readouterr().out)
    assert emitted["command"] == "backpack preflight-mixed"
    assert emitted["status"] == "WAITING_FOR_DIMENSION_LOCATORS"


def test_solve_auto_consumes_a_sealed_dimension_locator(tmp_path: Path) -> None:
    partial = tmp_path / "partial.jsonl"
    _dimension_rows(partial)
    final = tmp_path / "final.jsonl"
    final_row = {
        "schema": "banana-smasher-dynamic-backpack-candidate-ledger-row-v2",
        "status": "ADMITTED_COMPLETE_ALLOCATION_ELIGIBLE",
        "allocation_eligible": True,
        "basis_sha256": BASIS,
        "candidate_id": "L002.E000.down.qtip2",
        "layer": 2,
        "expert": 0,
        "projection": "down",
        "tier": "qtip2",
        "physical_bytes": 1,
        "six_class_predictions": {name: 1.0 for name in CLASSES},
        "activation_artifacts": [],
    }
    final.write_text(json.dumps(final_row, sort_keys=True) + "\n")
    locator = tmp_path / "final-locator.json"
    _write_json(
        locator,
        {
            "schema": "banana-smasher-mixed-backpack-dimensions-locator-v1",
            "status": "SEALED",
            "basis_sha256": BASIS,
            "dimensions": {
                "path": final.name,
                "sha256": hashlib.sha256(final.read_bytes()).hexdigest(),
            },
        },
    )
    config = tmp_path / "mixed.json"
    _write_json(
        config,
        {
            "schema": "banana-smasher-mixed-backpack-config-v1",
            "basis_sha256": BASIS,
            "target": {
                "whole_model_bytes": 14,
                "fixed_nonexpert_bytes": 10,
                "exact": True,
            },
            "allowed_tiers": ["qtip2", "qtip3"],
            "fallback_tier": "qtip2",
            "topology": {
                "layers": [0, 1, 2],
                "experts_per_layer": 1,
                "projections": ["down"],
            },
            "dimensions": {
                "sources": [
                    {
                        "path": partial.name,
                        "sha256": hashlib.sha256(partial.read_bytes()).hexdigest(),
                    },
                    {"locator_path": locator.name},
                ]
            },
            "class_caps": {name: 10.0 for name in CLASSES},
        },
    )

    receipt = solve_mixed_backpack_config(config, output=tmp_path / "solve")

    assert receipt["sources"]["admitted"] == 2
    assert receipt["sources"]["pending"] == 0
    assert json.loads((tmp_path / "solve/identity.json").read_text())["assignment"] == {
        "L000.E000": "qtip3",
        "L001.E000": "qtip2",
        "L002.E000": "qtip2",
    }


def test_preflight_consumes_sealed_physical_locator_without_inventing_dimensions(
    tmp_path: Path,
) -> None:
    partial = tmp_path / "partial.jsonl"
    _dimension_rows(partial)
    manifest = tmp_path / "physical-terminal.json"
    _write_json(
        manifest,
        {
            "schema": "banana-smasher-qtip2-v7-regeneration-terminal-v1",
            "status": "PASS",
            "basis_sha256": BASIS,
            "members_expected": 1,
            "members_complete": 1,
            "gaps": 0,
            "duplicates": 0,
            "members": [{"member": "L000/E000/w1", "bytes": 1}],
        },
    )
    locator = tmp_path / "physical-locator.json"
    _write_json(
        locator,
        {
            "schema": "banana-smasher-mixed-backpack-physical-locator-v1",
            "status": "SEALED",
            "basis_sha256": BASIS,
            "physical_manifest": {
                "path": manifest.name,
                "sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(),
            },
        },
    )
    config = tmp_path / "mixed.json"
    _write_json(
        config,
        {
            "schema": "banana-smasher-mixed-backpack-config-v1",
            "basis_sha256": BASIS,
            "target": {
                "whole_model_bytes": 13,
                "fixed_nonexpert_bytes": 10,
                "exact": True,
            },
            "allowed_tiers": ["qtip2", "qtip3"],
            "fallback_tier": "qtip2",
            "topology": {
                "layers": [0, 1, 2],
                "experts_per_layer": 1,
                "projections": ["down"],
            },
            "dimensions": {
                "sources": [
                    {
                        "path": partial.name,
                        "sha256": hashlib.sha256(partial.read_bytes()).hexdigest(),
                    },
                    {"locator_path": locator.name},
                    {"locator_path": "still-pending.json"},
                ]
            },
            "class_caps": {name: 10.0 for name in CLASSES},
        },
    )

    receipt = preflight_mixed_backpack_config(config)

    assert receipt["sources"] == {"admitted": 2, "pending": 1}
    assert receipt["missing_fallback_projection_cells"] == ["L002.E000.down"]
    physical = receipt["admitted_sources"][1]
    assert physical["kind"] == "physical_inventory"
    assert physical["rows"] == 0
    assert physical["path"] == str(manifest)


def test_preflight_and_solve_consume_explicit_expert_sensitivity_rows(
    tmp_path: Path,
) -> None:
    sensitivity = tmp_path / "sensitivity.jsonl"
    rows = []
    for layer, tiers in ((0, ("Q2", "QTIP3_V7")), (1, ("Q2",))):
        for tier in tiers:
            rows.append(
                {
                    "schema": "banana-smasher-sensitivity-row-v1",
                    "basis_sha256": BASIS,
                    "layer": layer,
                    "expert": 0,
                    "tier": tier,
                    "bytes": 2 if tier == "Q2" else 3,
                    "routing_mass": 2.0,
                    "activation_relative_rms": 1.0 if tier == "Q2" else 0.1,
                    "predicted_delta_contribution": 2.0 if tier == "Q2" else 0.2,
                    "projection_terms": {
                        "down": {"relative_output_rms": 0.5},
                        "fused13": {"relative_output_rms": 0.5},
                    },
                    "source_receipts": [],
                }
            )
    sensitivity.write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    )
    config = tmp_path / "mixed.json"
    _write_json(
        config,
        {
            "schema": "banana-smasher-mixed-backpack-config-v1",
            "basis_sha256": BASIS,
            "target": {
                "whole_model_bytes": 15,
                "fixed_nonexpert_bytes": 10,
                "exact": True,
            },
            "allowed_tiers": ["qtip2", "qtip3"],
            "fallback_tier": "qtip2",
            "topology": {
                "layers": [0, 1],
                "experts_per_layer": 1,
                "projections": ["down", "fused13"],
            },
            "dimensions": {
                "path": sensitivity.name,
                "sha256": hashlib.sha256(sensitivity.read_bytes()).hexdigest(),
            },
            "class_caps": {name: 100.0 for name in CLASSES},
        },
    )

    preflight = preflight_mixed_backpack_config(config)
    assert preflight["ready_to_solve"] is True
    assert preflight["coverage"]["qtip2"]["available_projection_cells"] == 4
    assert preflight["coverage"]["qtip3"]["available_projection_cells"] == 2

    receipt = solve_mixed_backpack_config(config, output=tmp_path / "solve")
    assert receipt["byte_accounting"]["whole_model_bytes"] == 15
    assert json.loads((tmp_path / "solve/identity.json").read_text())["assignment"] == {
        "L000.E000": "qtip3",
        "L001.E000": "qtip2",
    }


def test_sensitivity_rows_preserve_measured_physical_bytes_and_activations(
    tmp_path: Path,
) -> None:
    sensitivity = tmp_path / "sensitivity.jsonl"
    rows = []
    for tier in ("Q2", "QTIP3_V7"):
        row = {
            "schema": "banana-smasher-sensitivity-row-v1",
            "basis_sha256": BASIS,
            "layer": 0,
            "expert": 0,
            "tier": tier,
            "bytes": 2 if tier == "Q2" else 3,
            "routing_mass": 2.0,
            "predicted_delta_contribution": 2.0 if tier == "Q2" else 0.2,
            "projection_terms": {
                "down": {"relative_output_rms": 0.5},
                "fused13": {"relative_output_rms": 0.5},
            },
            "source_receipts": [],
        }
        if tier == "QTIP3_V7":
            row["physical_bytes"] = 4
            row["activation_artifacts"] = [{"id": "q3-layer0-lut", "bytes": 1}]
        rows.append(row)
    sensitivity.write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    )
    config = tmp_path / "mixed.json"
    _write_json(
        config,
        {
            "schema": "banana-smasher-mixed-backpack-config-v1",
            "basis_sha256": BASIS,
            "target": {
                "whole_model_bytes": 15,
                "fixed_nonexpert_bytes": 10,
                "exact": True,
            },
            "allowed_tiers": ["qtip2", "qtip3"],
            "fallback_tier": "qtip2",
            "topology": {
                "layers": [0],
                "experts_per_layer": 1,
                "projections": ["down", "fused13"],
            },
            "dimensions": {
                "path": sensitivity.name,
                "sha256": hashlib.sha256(sensitivity.read_bytes()).hexdigest(),
            },
            "class_caps": {name: 100.0 for name in CLASSES},
        },
    )

    receipt = solve_mixed_backpack_config(config, output=tmp_path / "solve")

    assert receipt["byte_accounting"]["candidate_payload_bytes"] == 5
    assignment = json.loads((tmp_path / "solve/ASSIGNMENT.json").read_text())
    assert assignment["activated_artifacts"] == [
        {"id": "q3-layer0-lut", "bytes": 1}
    ]


def test_solve_emits_hash_bound_selected_physical_members(tmp_path: Path) -> None:
    dimensions = tmp_path / "dimensions.jsonl"
    _dimension_rows(dimensions)
    physical = tmp_path / "qtip3-physical.json"
    members = [
        {
            "cell_id": f"L000.E000.{projection}",
            "tier": "qtip3",
            "artifact": {
                "host": "spark-7",
                "path": f"/sealed/L000/E000_{projection}/codes.npy",
                "sha256": digit * 64,
                "bytes": 11,
            },
        }
        for projection, digit in (("down", "1"), ("fused13", "2"))
    ]
    _write_json(
        physical,
        {
            "schema": "banana-smasher-mixed-backpack-physical-members-v1",
            "status": "SEALED",
            "basis_sha256": BASIS,
            "members_expected": 2,
            "members_complete": 2,
            "gaps": 0,
            "duplicates": 0,
            "members": members,
        },
    )
    locator = tmp_path / "qtip3-locator.json"
    _write_json(
        locator,
        {
            "schema": "banana-smasher-mixed-backpack-physical-locator-v1",
            "status": "SEALED",
            "basis_sha256": BASIS,
            "physical_manifest": {
                "path": physical.name,
                "sha256": hashlib.sha256(physical.read_bytes()).hexdigest(),
            },
        },
    )
    config = _config(tmp_path, target=13)
    value = json.loads(config.read_text())
    value["dimensions"] = {
        "sources": [
            {
                "path": dimensions.name,
                "sha256": hashlib.sha256(dimensions.read_bytes()).hexdigest(),
            },
            {"locator_path": locator.name},
        ]
    }
    _write_json(config, value)

    receipt = solve_mixed_backpack_config(config, output=tmp_path / "solve")

    roster_path = tmp_path / "solve/SELECTED_PHYSICAL_MEMBERS.json"
    roster = json.loads(roster_path.read_text())
    assert roster["schema"] == "banana-smasher-mixed-backpack-selected-members-v1"
    assert roster["basis_sha256"] == BASIS
    assert roster["members_expected"] == 1
    assert roster["members"] == members[:1]
    identity = json.loads((tmp_path / "solve/identity.json").read_text())
    assert identity["selected_physical_members"] == {
        "path": "SELECTED_PHYSICAL_MEMBERS.json",
        "sha256": hashlib.sha256(roster_path.read_bytes()).hexdigest(),
        "bytes": len(roster_path.read_bytes()),
        "members": 1,
    }
    assert receipt["selected_physical_members"] == identity["selected_physical_members"]

    incomplete = json.loads(physical.read_text())
    incomplete["members"] = members[1:]
    incomplete["members_expected"] = 1
    incomplete["members_complete"] = 1
    _write_json(physical, incomplete)
    locator_value = json.loads(locator.read_text())
    locator_value["physical_manifest"]["sha256"] = hashlib.sha256(
        physical.read_bytes()
    ).hexdigest()
    _write_json(locator, locator_value)

    with pytest.raises(
        DynamicDimensionsError,
        match=r"missing physical member binding .*down.*qtip3",
    ):
        solve_mixed_backpack_config(config, output=tmp_path / "incomplete-solve")


def test_bind_mixed_v7_physical_dimensions_charges_controls_and_shared_luts_once(
    tmp_path: Path,
) -> None:
    descriptor = {"path": "wire", "sha256": "b" * 64, "bytes": 7}
    q2_lut = {"path": "q2-lut", "sha256": "c" * 64, "bytes": 2}
    q3_lut = {"path": "q3-lut", "sha256": "d" * 64, "bytes": 3}
    contract = tmp_path / "contract.json"
    _write_json(
        contract,
        {
            "schema": "banana-smasher-mixed-v7-member-contract-v1",
            "status": "PASS_ADMISSION_READY",
            "basis_sha256": BASIS,
            "members": [
                {"cell_id": "L001.E000.w1", "tier": "qtip2", "payload": descriptor, "unit_metadata": {"tlut": q2_lut}},
            ],
        },
    )
    terminals = tmp_path / "terminals/L000"
    terminal_members = []
    for expert in range(256):
        for projection, payload_bytes, control_bytes in (
            ("down", 11, 5),
            ("fused13", 13, 6),
        ):
            terminal_members.append(
                {
                    "cell": f"E{expert:03d}_{projection}",
                    "codes": {"path": f"{expert}-{projection}-codes", "sha256": "e" * 64, "bytes": payload_bytes},
                    "control": {"path": f"{expert}-{projection}-control", "sha256": "f" * 64, "bytes": control_bytes},
                }
            )
    _write_json(
        terminals / "LAYER_PRODUCT_TERMINAL.json",
        {
            "schema": "banana-smasher-qtip3-full43-layer-product-v2",
            "status": "PASS",
            "basis_sha256": BASIS,
            "layer": 0,
            "cells": 512,
            "complete_members": 512,
            "gaps": 0,
            "duplicates": 0,
            "method": {"lut": q3_lut},
            "members": terminal_members,
        },
    )
    ledger = tmp_path / "sensitivity.jsonl"
    source_rows = []
    for tier, wire_bytes in (("Q2", 23), ("QTIP3_V7", 24)):
        source_rows.append(
            {
                "schema": "banana-smasher-sensitivity-row-v1",
                "basis_sha256": BASIS,
                "layer": 0,
                "expert": 0,
                "tier": tier,
                "bytes": wire_bytes,
                "predicted_delta_contribution": 0.1,
                "routing_mass": 0.0,
            }
        )
    ledger.write_text("".join(json.dumps(row) + "\n" for row in source_rows))

    result = bind_mixed_v7_physical_dimensions(
        sensitivity_ledger=ledger,
        member_contract=contract,
        qtip3_terminals=tmp_path / "terminals",
        basis_sha256=BASIS,
        output=tmp_path / "bound.jsonl",
        receipt=tmp_path / "receipt.json",
    )

    bound = [json.loads(line) for line in (tmp_path / "bound.jsonl").read_text().splitlines()]
    assert bound[0]["bytes"] == 23
    assert bound[0]["activation_artifacts"][0]["bytes"] == 2
    assert bound[1]["physical_bytes"] == 35
    assert bound[1]["activation_artifacts"][0]["bytes"] == 3
    assert result["qtip2_rows"] == 1
    assert result["qtip3_rows"] == 1
